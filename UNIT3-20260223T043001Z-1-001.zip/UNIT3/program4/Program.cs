﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Value p : ");
            float p = float.Parse(Console.ReadLine());

            Console.Write("Enter Value r : ");
            float r = float.Parse(Console.ReadLine());

            Console.Write("Enter value for n: ");
            float n = float.Parse(Console.ReadLine());


            float d = 1 + r / 100;

            float i;
            i = p * d;

            Console.WriteLine("interest = " + i);
        }
    }
}
