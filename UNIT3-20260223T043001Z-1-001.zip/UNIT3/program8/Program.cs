﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter number to know it's factoial : ");
            int a = int.Parse(Console.ReadLine());

            int i;
            int fact = 1;

            for (i = 1; i <= a; i++)
            {
                fact = fact * i;
            }

            Console.WriteLine("Factorial = " + fact);
        }
    }
}
