﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number: ");
            int number = int.Parse(Console.ReadLine());

            int original = number;
            int sum = 0;
            int digits = original.ToString().Length;

            while (number > 0)
            {
                int digit = number % 10;
                sum += (int)Math.Pow(digit, digits);
                number /= 10;
            }

            if (sum == original)
            {
                Console.WriteLine("It is Armstrong");
            }
            else
            {
                Console.WriteLine("It is not Armstrong");
            }
        }
    }
}
