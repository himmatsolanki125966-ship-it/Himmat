﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 0, b = 1, n, c;

            Console.Write("Enter number how many you want to Print: ");
            n = int.Parse(Console.ReadLine());

            Console.WriteLine("Fibonacci Series : ");

            Console.WriteLine(a + "");
            Console.WriteLine(b + "");

            c = a + b;

            while (c <= n)
            {

                Console.WriteLine(c + " ");
                a = b;
                b = c;
                c = a + b;
            }
        }
    }
}
