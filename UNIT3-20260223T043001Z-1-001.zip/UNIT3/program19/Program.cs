﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[5];


            for (int i = 0; i < 5; i++)
            {
                Console.Write("Enter number {0}: ", i + 1);
                numbers[i] = int.Parse(Console.ReadLine());
            }


            int min = numbers[0];
            for (int i = 1; i < 5; i++)
            {
                if (numbers[i] < min)
                {
                    min = numbers[i];
                }
            }

            Console.WriteLine("Minimum number is: {0}", min);
        }
    }
}
