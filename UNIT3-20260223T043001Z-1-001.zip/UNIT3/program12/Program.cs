﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, add = 0;

            Console.Write("enter a number : ");
            num = int.Parse(Console.ReadLine());

            while (num > 0)
            {
                add = add + (num % 10);
                num = num / 10;
            }
            Console.WriteLine("sum of digits = " + add);
        }
    }
}
