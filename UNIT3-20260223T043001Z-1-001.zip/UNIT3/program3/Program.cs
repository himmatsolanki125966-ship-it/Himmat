﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Value p : ");
            int p = int.Parse(Console.ReadLine());

            Console.Write("Enter Value r : ");
            int r = int.Parse(Console.ReadLine());

            Console.Write("Enter value for n: ");
            int n = int.Parse(Console.ReadLine());


            int i = p * r * n;

            i = i / 100;

            Console.WriteLine("interest = " + i);
        }
    }
}
