﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter value of Radius : ");
            int r = int.Parse(Console.ReadLine());

            Console.Write("Enter value for pi : ");
            float pi = float.Parse(Console.ReadLine());

            float area = pi * r * r;

            Console.WriteLine("Area = " + area);
        }
    }
}
