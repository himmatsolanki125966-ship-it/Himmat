﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayClass
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[10];
            int i;

            Console.WriteLine("Enter 10 values:");

            for (i = 0; i < 10; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Values in reverse order:");


            for (i = a.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(a[i]);
            }
        }
    }
}