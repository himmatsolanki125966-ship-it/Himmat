﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter starting range : ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("enter ending range : ");
            int b = int.Parse(Console.ReadLine());

            for (int n = a; n <= b; n++)
            {
                int c = 0;
                if (n <= 1)
                    c = 1;

                for (int i = 2; i <= n / 2; i++)
                {
                    if (n % i == 0)
                    {
                        c++;
                        break;
                    }
                }

                if (c == 0)
                    Console.Write("{0} ", n);
            }
            Console.Write("\n");
        }
    }
}
