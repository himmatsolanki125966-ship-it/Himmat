﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Value a : ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Enter Value B : ");
            int b = int.Parse(Console.ReadLine());

            int sum = a + b;
            int sub = a - b;
            int mul = a * b;
            int div = a / b;
            int mod = a % b;

            Console.WriteLine("addition = " + sum);
            Console.WriteLine("subtraction = " + sub);
            Console.WriteLine("multiplication = " + mul);
            Console.WriteLine("division = " + div);
            Console.WriteLine("modulaus = " + mod);
        }
    }
}
